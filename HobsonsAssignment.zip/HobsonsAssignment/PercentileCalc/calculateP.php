<?php
/*
  Use PHP 5.6.*.
  Use the following framework to read "data.csv" and calculate Percentile Rank.
*/
require_once(realpath(__DIR__) . "/../config/constants.php");
require_once(realpath(__DIR__) . "/../config/format.php"); 
if (DATASOURCE_TYPE === DATASOURCE_CSV ){
    require_once(realpath(__DIR__). "/csv_data_access.php");
}

// Get processed data.
$processedData = get_data();
$noOfStudents  = $processedData['noOfRecords'];


// Make a local copy
$scoreStore    = $processedData['scoreStore']; 

// Counts  no of scores lesser than students score
function countLowerScores($gpa, $index, $studentGPA){
    global $lowerScores; 
    if ($gpa < $studentGPA) {
       array_push($lowerScores, 'true');
    }
}

foreach ($processedData['studentInfo'] as $student){
    // List of scores less than students score.
    $lowerScores = array();
    // No of times score repeated.
    $frequency   = count(array_keys($processedData['scoreStore'], $student['GPA']));
    
    array_walk($scoreStore, "countLowerScores", $student['GPA']); 

    $noOfLowerScores = count($lowerScores);
    
    // Calculate Percentile
    $percentile  = ($noOfLowerScores/$noOfStudents + 0.5*$frequency/$noOfStudents)*100;
    print_r(sprintf($format, $student['studentName'], $student['GPA'], $percentile)); 
}
?>