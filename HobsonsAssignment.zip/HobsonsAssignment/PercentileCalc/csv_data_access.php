<?php
/*
  Use PHP 5.6.*.

  "data.csv" contains CSV-delimited records on each line in the
  following format:
    
    471908US,"Randy Perez",1.60

  Use the following framework to read "data.csv" and return formatted CSV data.
*/

require_once(realpath(__DIR__) . "/../config/constants.php");
require_once(realpath(__DIR__) . "/../utils/validator.php");


// Make a clean/valid, duplicate free record 
$finalCsvData       = array();

$studentInformation = array();
// List of scores in an Ascending order
$scoreStore         = array();

// No of records.
$noOfRecords;

// Debugging variable
$countOfIDPruned = 0;

// Catch the temporary variable to hold and check for duplicate ID
$currentIDpruned;

function get_data() {
  global  $studentInformation, $noOfRecords, $countOfIDPruned, $currentIDpruned;

  if (($handle = fopen(__DIR__."/../Data/data", "r")) !== FALSE) {
      
      function writeCSVData($h) {
  	    // Array to catch csvData on current line
        
        $csvData = fgetcsv($h, 0,",", ',');

        
        if(validate($csvData[0])) {

            $name = formatName($csvData[1]);

            $GLOBALS["finalCsvData"][] = array('id' => $csvData[0], 'studentName' => $name, 'GPA' => floatval($csvData[2])); 
            $GLOBALS["scoreStore"][] = floatval($csvData[2]); 
        }
      }

      // Read from each line
      while (!feof($handle)) {        
        writeCSVData($handle);
        $noOfRecords = $countOfIDPruned++;            
      }
      // make a local copy.
      $studentInformation = $GLOBALS["finalCsvData"];
      
      fclose($handle);

      // Sort columnwise
      foreach ($studentInformation as $key => $insert) {
          $GPA[$key]     = $insert['GPA'];
      }
      // SOrt the data.
      array_multisort($GPA, SORT_ASC, $studentInformation);

      return array('studentInfo' => $studentInformation, 'noOfRecords' =>  $noOfRecords, 'scoreStore' => $GLOBALS["scoreStore"]);

      //var_dump($studentInformation);
      //var_dump($GLOBALS["scoreStore"]); 
  }
}
?>