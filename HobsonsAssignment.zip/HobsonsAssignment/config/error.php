<?php
	
	require_once(realpath(__DIR__) . "/../config/constants.php");	

	function errorlog($msg){
		error_log($msg . PHP_EOL, 3, LOG_FILE);
	}


?>