<?php

	$format = "STUDENT NAME: %s                             GPA: %.2f              PERCENTILE: %.2f \n ";
?>