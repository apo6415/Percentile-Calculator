<?php
//data source
define("DATASOURCE_CSV","CSV");
define("DATASOURCE_JSON","JSON");
define("DATASOURCE_TYPE", DATASOURCE_CSV);


//Application paths


define("APPLICATION_NAME","GPA Calculator");
define("LOG_FILE",__DIR__ . "/../logs/calculator.log");


?>