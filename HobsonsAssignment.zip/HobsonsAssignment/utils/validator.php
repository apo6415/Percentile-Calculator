<?php
/*
    Apply vlaidations on text data
*/
function validate($studentID) {
    $valid     = isset($studentID);
    $validator = '/^\d{6}US$/';
    if ($valid) {
        $valid = preg_match($validator, $studentID);
    }

    return $valid;
}

function formatName($studentName) {
    
    return preg_replace('/[^\w\d\s]/', '', $studentName);

}


function validateRecordDuplicates ($fh) {
    // Add code in future to check duplicates in file and remove them.
    return true;
}

?>